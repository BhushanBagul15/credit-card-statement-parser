package com.example.demo.parser.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class AmountParser {
    public static String parseAmount (String amountStr){
        if(amountStr == null || amountStr.isBlank()){
            return null;
        }
        String cleanData = amountStr.replaceAll("[₹Rs.,\\sA-Z:a-z]+", "").trim();

        cleanData = cleanData.replaceAll("(\\.){2,}",".");

        if(!cleanData.matches("\\d+(\\.\\d{1,2})?")){
            cleanData = cleanData.replaceAll("[^0-9]","");
        }

        if(cleanData.isBlank()) return null;

        try{
            BigDecimal value = new BigDecimal(cleanData);
            DecimalFormat df = new DecimalFormat("0.00");
            return df.format(value);
        }catch(NumberFormatException e){
            return null;
        }
    }
}
